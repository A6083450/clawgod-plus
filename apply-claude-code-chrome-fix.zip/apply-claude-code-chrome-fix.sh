#!/bin/bash
#
# Claude Code Bridge Socket Fallback Fix Script
#
# THE ISSUE:
# Claude Code's MCP browser client always uses WebSocket bridge (requires OAuth),
# even when a local Unix socket / Named Pipe is available from the Chrome extension's
# native host. This prevents API Key mode users from using browser tools.
#
# ROOT CAUSE:
# In B4_(config), bridgeConfig is always present, so ei6() (WebSocket BridgeClient)
# is always chosen. The getSocketPaths (Unix Socket) and ri6() (Native Messaging)
# paths are dead code:
#   return H.bridgeConfig ? ei6(H) : H.getSocketPaths ? uFA(H) : ri6(H)
#
# FIX:
# Prefer SocketClient (uFA) whenever getSocketPaths is configured. SocketClient
# owns asynchronous socket discovery and refresh, so the factory must not inspect
# the result synchronously. Also preserve --chrome/--no-chrome through
# `claude agents` dispatches so background sessions keep the MCP server.
#
# Usage:
#   ./apply-claude-code-chrome-fix.sh                    # Apply fix
#   ./apply-claude-code-chrome-fix.sh /path/to/cli.js    # Specific file
#   ./apply-claude-code-chrome-fix.sh --check            # Check only
#   ./apply-claude-code-chrome-fix.sh --restore          # Restore backup
#

set -e

BACKUP_SUFFIX="backup-bridge-fallback"
FIX_DESCRIPTION="Prefer the local Chrome socket client (for API Key mode)"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

success() { echo -e "${GREEN}[OK]${NC} $1"; }
warning() { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[X]${NC} $1"; }
info() { echo -e "${BLUE}[>]${NC} $1"; }

CHECK_ONLY=false
RESTORE=false
CLI_PATH_ARG=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --check|-c) CHECK_ONLY=true; shift ;;
        --restore|-r) RESTORE=true; shift ;;
        --help|-h)
            echo "Usage: $0 [options] [cli.js path]"
            echo ""
            echo "$FIX_DESCRIPTION"
            echo ""
            echo "Options:"
            echo "  --check, -c    Check if fix is needed"
            echo "  --restore, -r  Restore from backup"
            echo "  --help, -h     Show help"
            exit 0
            ;;
        -*) error "Unknown option: $1"; exit 1 ;;
        *) if [[ -z "$CLI_PATH_ARG" ]]; then CLI_PATH_ARG="$1"; else error "Unexpected: $1"; exit 1; fi; shift ;;
    esac
done

find_cli_path() {
    local path="$HOME/.clawgod/cli.original.cjs"
    if [[ -f "$path" ]]; then
        echo "$path"
        return 0
    fi
    return 1
}

resolve_bun() {
    if command -v bun >/dev/null 2>&1; then
        command -v bun
        return 0
    fi
    if [[ -x "$HOME/.bun/bin/bun" ]]; then
        echo "$HOME/.bun/bin/bun"
        return 0
    fi
    return 1
}

if [[ -n "$CLI_PATH_ARG" ]]; then
    if [[ -f "$CLI_PATH_ARG" ]]; then
        CLI_PATH="$CLI_PATH_ARG"
        info "Using specified cli.js: $CLI_PATH"
    else
        error "File not found: $CLI_PATH_ARG"
        exit 1
    fi
else
    CLI_PATH=$(find_cli_path) || {
        error "Claude Code cli.js not found"
        echo ""
        echo "Tip: Specify the path directly:"
        echo "  $0 /path/to/cli.js"
        exit 1
    }
    info "Found Claude Code: $CLI_PATH"
fi

CLI_DIR=$(dirname "$CLI_PATH")
CLI_BASE=$(basename "$CLI_PATH")

if $RESTORE; then
    LATEST_BACKUP=$(ls -t "$CLI_DIR"/"$CLI_BASE".${BACKUP_SUFFIX}-* 2>/dev/null | head -1)
    if [[ -n "$LATEST_BACKUP" ]]; then
        cp "$LATEST_BACKUP" "$CLI_PATH"
        success "Restored from backup: $LATEST_BACKUP"
        exit 0
    else
        error "No backup found"
        exit 1
    fi
fi

echo ""

BUN_BIN=$(resolve_bun) || {
    error "Bun is required. Install Bun: https://bun.sh/docs/installation"
    exit 1
}

ACORN_PATH="${TMPDIR:-/tmp}/acorn-8.16.0.cjs"
if [[ ! -f "$ACORN_PATH" ]]; then
    info "Downloading acorn parser..."
    FETCH_SCRIPT=$(mktemp "${TMPDIR:-/tmp}/acorn-fetch-XXXXXX.mjs")
    cat > "$FETCH_SCRIPT" <<'FETCH_EOF'
import { existsSync, renameSync, rmSync } from 'node:fs';

const [url, destination] = process.argv.slice(2);
if (!url || !destination) throw new Error('usage: acorn fetcher <url> <destination>');

function noProxyRule(value) {
  let entry = value.trim().toLowerCase();
  if (entry === '*') return { all: true };
  let host = entry;
  let port = '';
  if (entry.startsWith('[')) {
    const close = entry.indexOf(']');
    if (close === -1) return { host: entry, port };
    host = entry.slice(1, close);
    const suffix = entry.slice(close + 1);
    if (/^:\d+$/.test(suffix)) port = suffix.slice(1);
    else if (suffix) return { host: entry, port };
  } else {
    const colon = entry.lastIndexOf(':');
    if (colon > 0 && colon === entry.indexOf(':') && /^\d+$/.test(entry.slice(colon + 1))) {
      host = entry.slice(0, colon);
      port = entry.slice(colon + 1);
    }
  }
  return { host: host.replace(/^\*\./, '.'), port };
}

function bypassesProxy(urlValue) {
  const parsed = typeof urlValue === 'string' ? new URL(urlValue) : urlValue;
  const entries = (process.env.NO_PROXY || process.env.no_proxy || '').split(',').filter(value => value.trim());
  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  const port = parsed.port || (parsed.protocol === 'https:' ? '443' : parsed.protocol === 'http:' ? '80' : '');
  return entries.some(entry => {
    const rule = noProxyRule(entry);
    if (rule.all) return true;
    const baseHost = rule.host.replace(/^\./, '');
    return (host === baseHost || host.endsWith(`.${baseHost}`)) && (!rule.port || rule.port === port);
  });
}

function proxyFor(urlValue) {
  const parsed = new URL(urlValue);
  if (bypassesProxy(parsed)) return undefined;
  return parsed.protocol === 'https:'
    ? process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy
    : process.env.HTTP_PROXY || process.env.http_proxy;
}

async function fetchDirect(url, init, fetchImpl) {
  const upper = Object.hasOwn(process.env, 'NO_PROXY') ? process.env.NO_PROXY : undefined;
  const lower = Object.hasOwn(process.env, 'no_proxy') ? process.env.no_proxy : undefined;
  try {
    process.env.NO_PROXY = '*';
    process.env.no_proxy = '*';
    return await fetchImpl(url, init);
  } finally {
    if (upper === undefined) delete process.env.NO_PROXY;
    else process.env.NO_PROXY = upper;
    if (lower === undefined) delete process.env.no_proxy;
    else process.env.no_proxy = lower;
  }
}

async function fetchWithProxy(initialUrl) {
  let nextUrl = initialUrl;
  for (let redirects = 0; redirects <= 5; redirects++) {
    const bypass = bypassesProxy(nextUrl);
    const proxy = proxyFor(nextUrl);
    let response;
    try {
      const init = { redirect: 'manual', signal: AbortSignal.timeout(300000), ...(proxy ? { proxy } : {}) };
      response = bypass ? await fetchDirect(nextUrl, init, fetch) : await fetch(nextUrl, init);
    } catch (error) {
      if (proxy) throw new Error('Request failed through configured proxy');
      throw error;
    }
    if (response.status >= 300 && response.status < 400 && response.headers.has('location')) {
      if (redirects === 5) throw new Error('Too many redirects');
      nextUrl = new URL(response.headers.get('location'), nextUrl).href;
      continue;
    }
    if (response.status !== 200) throw new Error(`Request failed with HTTP ${response.status}`);
    return response;
  }
  throw new Error('Too many redirects');
}

const temporary = `${destination}.${process.pid}.tmp`;
try {
  await Bun.write(temporary, await fetchWithProxy(url));
  renameSync(temporary, destination);
} finally {
  if (existsSync(temporary)) rmSync(temporary, { force: true });
}
FETCH_EOF
    set +e
    "$BUN_BIN" "$FETCH_SCRIPT" "https://unpkg.com/acorn@8.16.0/dist/acorn.js" "$ACORN_PATH"
    FETCH_EXIT=$?
    set -e
    rm -f "$FETCH_SCRIPT"
    if [[ $FETCH_EXIT -ne 0 ]]; then
        error "Failed to download acorn"
        exit 1
    fi
fi

PATCH_SCRIPT=$(mktemp)
cat > "$PATCH_SCRIPT" << 'PATCH_EOF'
const fs = require('fs');
const acorn = require(process.argv[2]);
const cliPath = process.argv[3];
const checkOnly = process.argv[4] === '--check';
const backupSuffix = process.env.BACKUP_SUFFIX || 'backup';

let code = fs.readFileSync(cliPath, 'utf-8');

let shebang = '';
if (code.startsWith('#!')) {
    const idx = code.indexOf('\n');
    shebang = code.slice(0, idx + 1);
    code = code.slice(idx + 1);
}

let fixes = {
    clientFactory: { found: false, patched: false, node: null },
    subscriptionGate: { found: false, patched: false, node: null },
    subscriptionMsg: { found: false, patched: false, node: null },
    selectBrowserHide: { found: false, patched: false, node: null },
    oauthScopeGate: { found: false, patched: false, node: null },
    agentsConfigState: { found: false, patched: false, node: null },
    agentsFlagParser: { found: false, patched: false, node: null },
    agentsConfigResolver: { found: false, patched: false, node: null },
    agentsDispatchArgs: { found: false, patched: false, node: null }
};

// Parse AST
let ast;
try {
    ast = acorn.parse(code, { ecmaVersion: "latest", sourceType: 'module' });
} catch (e) {
    console.error('PARSE_ERROR:' + e.message);
    process.exit(1);
}

function findNodes(node, predicate, results = []) {
    if (!node || typeof node !== 'object') return results;
    if (predicate(node)) results.push(node);
    for (const key in node) {
        if (node[key] && typeof node[key] === 'object') {
            if (Array.isArray(node[key])) {
                node[key].forEach(child => findNodes(child, predicate, results));
            } else {
                findNodes(node[key], predicate, results);
            }
        }
    }
    return results;
}

const src = (node) => code.slice(node.start, node.end);

const legacyClientFactoryRe = /function ([\w$]+)\(([\w$]+)\)\{if\(\2\.getSocketPaths\)\{var __paths=\2\.getSocketPaths\(\);if\(__paths&&__paths\.length>0\)return ([\w$]+\(\2\))\}return \2\.bridgeConfig\?([\w$]+\(\2\)):([\w$]+\(\2\))\}\/\*__ccpp_bridge_fallback\*\//;
const legacyClientFactory = legacyClientFactoryRe.exec(code);
if (legacyClientFactory) {
    fixes.clientFactory.found = true;
    fixes.clientFactory.node = {
        type: 'LegacyClientFactory',
        start: legacyClientFactory.index,
        end: legacyClientFactory.index + legacyClientFactory[0].length,
        match: legacyClientFactory
    };
}

// ============================================================
// Find B4_() — the client factory function
// Structural pattern:
//   function XXX(H) {
//     return H.bridgeConfig ? YYY(H) : H.getSocketPaths ? ZZZ(H) : WWW(H)
//   }
// This is a function with:
//   - 1 param
//   - body is single ReturnStatement
//   - return value is nested ConditionalExpression
//   - test uses .bridgeConfig and .getSocketPaths
// ============================================================

const funcDecls = findNodes(ast, n => n.type === 'FunctionDeclaration');
const arrowFuncs = findNodes(ast, n => n.type === 'ArrowFunctionExpression');

function isClientFactory(node) {
    // Get body statements
    let bodyStmts;
    if (node.body && node.body.type === 'BlockStatement') {
        bodyStmts = node.body.body;
    } else {
        return false;
    }

    // Must have exactly 1 param
    if (!node.params || node.params.length !== 1) return false;

    // Must have single return statement
    if (bodyStmts.length !== 1 || bodyStmts[0].type !== 'ReturnStatement') return false;

    const ret = bodyStmts[0].argument;
    if (!ret || ret.type !== 'ConditionalExpression') return false;

    // Outer ternary: H.bridgeConfig ? X : Y
    if (ret.test.type !== 'MemberExpression') return false;
    if (ret.test.property.name !== 'bridgeConfig') return false;

    // Inner ternary in alternate: H.getSocketPaths ? X : Y
    const alt = ret.alternate;
    if (!alt || alt.type !== 'ConditionalExpression') return false;
    if (alt.test.type !== 'MemberExpression') return false;
    if (alt.test.property.name !== 'getSocketPaths') return false;

    return true;
}

// Search both function declarations and variable-assigned functions
for (const fn of fixes.clientFactory.found ? [] : funcDecls) {
    if (isClientFactory(fn)) {
        fixes.clientFactory.found = true;
        fixes.clientFactory.node = fn;
        console.log('FOUND:clientFactory function ' + fn.id.name + ' -> ' + src(fn).slice(0, 80));
        break;
    }
}

if (!fixes.clientFactory.found) {
    // Also check VariableDeclarators with arrow/function expressions
    const varDecls = findNodes(ast, n => n.type === 'VariableDeclarator');
    for (const decl of varDecls) {
        if (decl.init && (decl.init.type === 'ArrowFunctionExpression' || decl.init.type === 'FunctionExpression')) {
            if (isClientFactory(decl.init)) {
                fixes.clientFactory.found = true;
                fixes.clientFactory.node = decl;
                console.log('FOUND:clientFactory var ' + (decl.id?.name || '?') + ' -> ' + src(decl).slice(0, 80));
                break;
            }
        }
    }
}

// ============================================================
// Find subscription gate: pH = FBH(.chrome) && vA()
// Structural: VariableDeclarator with LogicalExpression(&&)
//   left: CallExpression(arg is MemberExpr .chrome)
//   right: CallExpression(0 args)
// AND near anchor string "tengu_claude_in_chrome_setup"
// ============================================================

if (!code.includes('__ccpp_sub_bypass')) {
    // Structural match: VariableDeclarator where:
    //   init = LogicalExpression(&&)
    //   left = CallExpression(arg is MemberExpression .chrome)
    //   right = CallExpression(0 args)
    //   left callee's function body contains "claudeInChromeDefaultEnabled"
    const varDeclarators = findNodes(ast, n => n.type === 'VariableDeclarator');
    for (const decl of varDeclarators) {
        if (!decl.init || decl.init.type !== 'LogicalExpression' || decl.init.operator !== '&&') continue;
        const left = decl.init.left;
        const right = decl.init.right;
        if (left.type !== 'CallExpression' || !left.arguments?.length) continue;
        const arg = left.arguments[0];
        if (!arg || arg.type !== 'MemberExpression' || arg.property?.name !== 'chrome') continue;
        if (right.type !== 'CallExpression') continue;
        if (right.arguments?.length !== 0) continue;
        // Verify left callee is the chrome config function (contains claudeInChromeDefaultEnabled)
        const calleeName = left.callee?.name || left.callee?.property?.name;
        if (!calleeName) continue;
        const calleeDefs = findNodes(ast, n =>
            (n.type === 'FunctionDeclaration' && n.id?.name === calleeName) ||
            (n.type === 'VariableDeclarator' && n.id?.name === calleeName)
        );
        let verified = false;
        for (const def of calleeDefs) {
            if (src(def).includes('claudeInChromeDefaultEnabled')) { verified = true; break; }
        }
        if (!verified) continue;
        fixes.subscriptionGate.found = true;
        fixes.subscriptionGate.node = decl;
        console.log('FOUND:subscriptionGate ' + decl.id.name + ' -> ' + src(decl).slice(0, 60));
        break;
    }
}

// ============================================================
// Find /chrome subscription message: "Claude in Chrome requires a claude.ai subscription."
// In unpatched code: !f && createElement(...)
// Anchor: the subscription message string itself
// If condition is already "false&&", skip (already patched by CCometixLine)
// ============================================================

if (!code.includes('__ccpp_sub_msg_bypass')) {
    const msgAnchor = 'Claude in Chrome requires a claude.ai subscription.';
    const msgPos = code.indexOf(msgAnchor);
    if (msgPos >= 0) {
        // Check if already patched (false&&)
        const before = code.slice(Math.max(0, msgPos - 200), msgPos);
        if (!before.includes('false&&')) {
            // Find the !f&& or !X&& condition before createElement
            // Pattern: LogicalExpression with !UnaryExpression on left, createElement on right
            // containing our anchor string
            const logicals = findNodes(ast, n => {
                if (n.type !== 'LogicalExpression' || n.operator !== '&&') return false;
                if (n.start > msgPos || n.end < msgPos) return false;
                if (n.left?.type !== 'UnaryExpression' || n.left.operator !== '!') return false;
                return true;
            });
            if (logicals.length > 0) {
                // Get the smallest (most specific) enclosing one
                const target = logicals.reduce((a, b) => (b.end - b.start) < (a.end - a.start) ? b : a);
                fixes.subscriptionMsg.found = true;
                fixes.subscriptionMsg.node = target.left; // the !f part
                console.log('FOUND:subscriptionMsg -> ' + src(target.left));
            }
        }
    }
}

// Explicit --chrome uses the local socket client and does not require the
// Claude.ai OAuth scopes checked by the bridge path.
if (!code.includes('__ccpp_chrome_oauth_scope_bypass')) {
    const match = /function ([\w$]+)\(([\w$]+)\)\{if\(![\w$]+\(\)\)return [\w$]+\("\[Claude in Chrome\] Disabled: OAuth token has no scope accepted by \/api\/oauth\/validate[^"]*"\),!1;if\(\2===!0\)return!0;/.exec(code);
    if (match) {
        fixes.oauthScopeGate.found = true;
        fixes.oauthScopeGate.node = {
            start: match.index,
            end: match.index + match[0].length,
            replacement: `function ${match[1]}(${match[2]}){/*__ccpp_chrome_oauth_scope_bypass*/if(${match[2]}===!0)return!0;`
        };
        console.log('FOUND:oauthScopeGate -> ' + match[0].slice(0, 80));
    }
}

// ============================================================
// Find "Select browser…" menu item
// Structural: ObjectExpression with label:"Select browser…" and value:"select-browser"
// ============================================================

if (!code.includes('__ccpp_no_select_browser')) {
    const selectBrowserNodes = findNodes(ast, n => {
        if (n.type !== 'ObjectExpression') return false;
        const props = n.properties;
        if (!props || props.length < 2) return false;
        return props.some(p => p.key?.name === 'value' && p.value?.value === 'select-browser');
    });
    if (selectBrowserNodes.length > 0) {
        fixes.selectBrowserHide.found = true;
        fixes.selectBrowserHide.node = selectBrowserNodes[0];
        console.log('FOUND:selectBrowserHide -> ' + src(selectBrowserNodes[0]).slice(0, 60));
    }
}

// ============================================================
// Preserve Chrome flags when `claude agents` dispatches sessions.
// Upstream persists only selected config fields into background jobs; without
// these additions, the Fleet View host has /claude-in-chrome but child sessions
// do not receive the claude-in-chrome MCP server.
// ============================================================

function findRegexFix(name, pattern, replacement) {
    const m = pattern.exec(code);
    if (!m) return;
    const value = typeof replacement === 'function' ? replacement(m) : replacement;
    fixes[name].found = true;
    fixes[name].node = { start: m.index, end: m.index + m[0].length, replacement: value };
    console.log('FOUND:' + name + ' -> ' + m[0].slice(0, 80));
}

if (!code.includes('strictMcpConfig:!1,chrome:!1,noChrome:!1')) {
    findRegexFix(
        'agentsConfigState',
        /[rn]=\{addDir:\[\],pluginDir:\[\],pluginDirNoMcp:\[\],settings:void 0,mcpConfig:\[\],strictMcpConfig:!1\}/g,
        (m) => m[0][0] + '={addDir:[],pluginDir:[],pluginDirNoMcp:[],settings:void 0,mcpConfig:[],strictMcpConfig:!1,chrome:!1,noChrome:!1}'
    );
}

if (!code.includes('if(a==="--chrome"){r.chrome=!0;continue}') && !code.includes('if(a==="--chrome"){n.chrome=!0;continue}')) {
    findRegexFix(
        'agentsFlagParser',
        /if\(a==="--strict-mcp-config"\)\{([a-z])\.strictMcpConfig=!0;continue\}/g,
        (m) => `if(a==="--chrome"){${m[1]}.chrome=!0;continue}if(a==="--no-chrome"){${m[1]}.noChrome=!0;continue}` + m[0]
    );
}

if (!code.includes('chrome:e.chrome&&!e.noChrome,noChrome:e.noChrome')) {
    findRegexFix(
        'agentsConfigResolver',
        /strictMcpConfig:e\.strictMcpConfig\}\}function ([\w$]+)/g,
        (m) => `strictMcpConfig:e.strictMcpConfig,chrome:e.chrome&&!e.noChrome,noChrome:e.noChrome}}function ${m[1]}`
    );
}

if (!code.includes('__ccpp_agents_chrome_dispatch')) {
    findRegexFix(
        'agentsDispatchArgs',
        /\.\.\.e\.strictMcpConfig\?\["--strict-mcp-config"\]:\[\]\]\}/g,
        '...e.chrome?["--chrome"/*__ccpp_agents_chrome_dispatch*/]:[],...e.noChrome?["--no-chrome"]:[],...e.strictMcpConfig?["--strict-mcp-config"]:[]]}'
    );
}

// Check if already patched
const allAlreadyPatched = code.includes('__ccpp_bridge_fallback_v2') &&
    (code.includes('__ccpp_chrome_oauth_scope_bypass') || !code.includes('OAuth token has no scope accepted by /api/oauth/validate')) &&
    (code.includes('__ccpp_sub_bypass') || !code.includes('tengu_claude_in_chrome_setup')) &&
    (code.includes('__ccpp_sub_msg_bypass') || !code.includes('Claude in Chrome requires a claude.ai subscription.')) &&
    (code.includes('__ccpp_no_select_browser') || !code.includes('select-browser')) &&
    code.includes('strictMcpConfig:!1,chrome:!1,noChrome:!1') &&
    (code.includes('if(a==="--chrome"){r.chrome=!0;continue}') || code.includes('if(a==="--chrome"){n.chrome=!0;continue}')) &&
    code.includes('chrome:e.chrome&&!e.noChrome,noChrome:e.noChrome') &&
    code.includes('__ccpp_agents_chrome_dispatch');
if (allAlreadyPatched && !Object.values(fixes).some(f => f.found)) {
    console.log('ALREADY_PATCHED');
    process.exit(2);
}
if (!Object.values(fixes).some(f => f.found)) {
    console.error('NOT_FOUND:No patchable patterns found');
    process.exit(1);
}

if (checkOnly) {
    console.log('NEEDS_PATCH');
    const count = Object.values(fixes).filter(f => f.found).length;
    console.log('PATCH_COUNT:' + count);
    process.exit(1);
}

// ============================================================
// Apply fix: prefer the socket pool when socket discovery is configured
// ============================================================

let newCode = code;
let replacements = [];

if (fixes.clientFactory.found && fixes.clientFactory.node) {
    const node = fixes.clientFactory.node;
    if (node.type === 'LegacyClientFactory') {
        const m = node.match;
        replacements.push({
            start: node.start,
            end: node.end,
            replacement: `function ${m[1]}(${m[2]}){return ${m[2]}.getSocketPaths?${m[3]}:${m[2]}.bridgeConfig?${m[4]}:${m[5]}}/*__ccpp_bridge_fallback_v2*/`,
            name: 'clientFactory'
        });
        fixes.clientFactory.patched = true;
        console.log('PATCH:clientFactory - Upgraded legacy synchronous socket probe');
    } else {

    // Get the function body — extract the return statement's conditional
    let fnNode, paramName;
    if (node.type === 'FunctionDeclaration') {
        fnNode = node;
        paramName = node.params[0].name;
    } else {
        // VariableDeclarator
        fnNode = node.init;
        paramName = fnNode.params[0].name;
    }

    const retStmt = fnNode.body.body[0];
    const cond = retStmt.argument;

    // Extract the three factory call names from the ternary
    // cond: H.bridgeConfig ? bridgeFactory(H) : H.getSocketPaths ? socketFactory(H) : nativeFactory(H)
    const bridgeCall = src(cond.consequent);   // ei6(H) or similar
    const socketCall = src(cond.alternate.consequent);  // uFA(H) or similar
    const nativeCall = src(cond.alternate.alternate);   // ri6(H) or similar

    // Socket discovery may be asynchronous; the socket pool client owns
    // discovery and refresh, so the factory must not inspect paths itself.
    const newReturn = `{return ${paramName}.getSocketPaths?${socketCall}:${paramName}.bridgeConfig?${bridgeCall}:${nativeCall}}/*__ccpp_bridge_fallback_v2*/`;

    // Replace the function body
    const bodyNode = fnNode.body;
    replacements.push({
        start: bodyNode.start,
        end: bodyNode.end,
        replacement: newReturn,
        name: 'clientFactory'
    });

    fixes.clientFactory.patched = true;
    console.log('PATCH:clientFactory - Socket priority over bridge when local socket available');
    }
}

if (fixes.oauthScopeGate.found && fixes.oauthScopeGate.node) {
    const node = fixes.oauthScopeGate.node;
    replacements.push({ start: node.start, end: node.end, replacement: node.replacement, name: 'oauthScopeGate' });
    fixes.oauthScopeGate.patched = true;
    console.log('PATCH:oauthScopeGate - Allowed explicit --chrome for local socket mode');
}

// ── Subscription gate: remove && vA() ──
if (fixes.subscriptionGate.found && fixes.subscriptionGate.node) {
    const decl = fixes.subscriptionGate.node;
    const right = decl.init.right; // vA() call
    const left = decl.init.left;   // FBH(.chrome) call
    // Replace the whole init (FBH(.chrome) && vA()) with just FBH(.chrome)
    replacements.push({
        start: decl.init.start,
        end: decl.init.end,
        replacement: src(left) + '/*__ccpp_sub_bypass*/',
        name: 'subscriptionGate'
    });
    fixes.subscriptionGate.patched = true;
    console.log('PATCH:subscriptionGate - Removed subscription check for Chrome features');
}

// ── Subscription message: replace !f with false ──
if (fixes.subscriptionMsg.found && fixes.subscriptionMsg.node) {
    const node = fixes.subscriptionMsg.node;
    replacements.push({
        start: node.start,
        end: node.end,
        replacement: 'false/*__ccpp_sub_msg_bypass*/',
        name: 'subscriptionMsg'
    });
    fixes.subscriptionMsg.patched = true;
    console.log('PATCH:subscriptionMsg - Hidden subscription requirement message in /chrome');
}

// ── Hide "Select browser" menu item ──
// Can't remove the if block (breaks React memo cache slots).
// Instead: find the m.push(KH) call inside the if block and replace with empty statement.
if (fixes.selectBrowserHide.found && fixes.selectBrowserHide.node) {
    const sbNode = fixes.selectBrowserHide.node;
    // Find the CallExpression: m.push(KH) that's inside the same if block
    const pushCalls = findNodes(ast, n => {
        if (n.type !== 'CallExpression') return false;
        if (n.callee?.property?.name !== 'push') return false;
        // Must be near and after the select-browser ObjectExpression
        if (n.start < sbNode.start || n.start - sbNode.end > 200) return false;
        return true;
    });
    if (pushCalls.length > 0) {
        // Find the enclosing ExpressionStatement to replace cleanly
        const pushCall = pushCalls[0];
        replacements.push({
            start: pushCall.start,
            end: pushCall.end,
            replacement: 'void 0/*__ccpp_no_select_browser*/',
            name: 'selectBrowserHide'
        });
        fixes.selectBrowserHide.patched = true;
        console.log('PATCH:selectBrowserHide - Disabled Select browser push');
    }
}

for (const name of ['agentsConfigState', 'agentsFlagParser', 'agentsConfigResolver', 'agentsDispatchArgs']) {
    if (fixes[name].found && fixes[name].node) {
        const node = fixes[name].node;
        replacements.push({
            start: node.start,
            end: node.end,
            replacement: node.replacement,
            name
        });
        fixes[name].patched = true;
        console.log('PATCH:' + name + ' - Preserved Chrome flags for claude agents sessions');
    }
}

// Apply replacements
replacements.sort((a, b) => b.start - a.start);
for (const r of replacements) {
    newCode = newCode.slice(0, r.start) + r.replacement + newCode.slice(r.end);
}

const patchedCount = Object.values(fixes).filter(f => f.patched).length;
if (patchedCount === 0) {
    console.error('VERIFY_FAILED:No fixes applied');
    process.exit(1);
}

const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const backupPath = cliPath + '.' + backupSuffix + '-' + timestamp;
fs.copyFileSync(cliPath, backupPath);
console.log('BACKUP:' + backupPath);

fs.writeFileSync(cliPath, shebang + newCode);
console.log('SUCCESS:' + patchedCount);
PATCH_EOF

CHECK_ARG=""
if $CHECK_ONLY; then
    CHECK_ARG="--check"
fi

export BACKUP_SUFFIX
set +e
OUTPUT=$("$BUN_BIN" "$PATCH_SCRIPT" "$ACORN_PATH" "$CLI_PATH" "$CHECK_ARG" 2>&1)
EXIT_CODE=$?
set -e

rm -f "$PATCH_SCRIPT"

while IFS= read -r line; do
    case "$line" in
        ALREADY_PATCHED)
            success "Already patched"
            exit 0
            ;;
        PARSE_ERROR:*)
            error "Failed to parse cli.js: ${line#PARSE_ERROR:}"
            exit 1
            ;;
        NOT_FOUND:*)
            error "Target not found: ${line#NOT_FOUND:}"
            exit 1
            ;;
        FOUND:*)
            info "Found: ${line#FOUND:}"
            ;;
        PATCH:*)
            info "Patch: ${line#PATCH:}"
            ;;
        NEEDS_PATCH)
            echo ""
            warning "Patch needed - run without --check to apply"
            ;;
        PATCH_COUNT:*)
            info "Need to patch ${line#PATCH_COUNT:} location(s)"
            exit 1
            ;;
        BACKUP:*)
            echo ""
            echo "Backup: ${line#BACKUP:}"
            ;;
        SUCCESS:*)
            echo ""
            success "Fix applied! Patched ${line#SUCCESS:} location(s)"
            echo ""
            warning "Restart Claude Code for changes to take effect"
            ;;
        VERIFY_FAILED:*)
            error "Verification failed: ${line#VERIFY_FAILED:}"
            exit 1
            ;;
    esac
done <<< "$OUTPUT"

exit $EXIT_CODE
